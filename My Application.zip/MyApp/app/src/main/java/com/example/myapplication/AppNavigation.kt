package com.example.myapplication

import androidx.compose.runtime.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier

// ==========================================
// Simple navigation manager using state
// ==========================================

// All screen routes
object Routes {
    const val HOME = "home"
    const val ENVIRONMENT = "environment"
    const val DASHBOARD = "dashboard"       // Plants tab
    const val TRENDS = "trends"
    const val SETTINGS = "settings"
    const val UV_LIGHT_DASHBOARD = "uv_light_dashboard"
}

// ==========================================
// Main App with navigation
// ==========================================
@Composable
fun PlantApp() {
    // Current screen state - shared across all screens
    var currentScreen by remember { mutableStateOf(Routes.HOME) }

    MaterialTheme {
        when (currentScreen) {
            Routes.HOME -> HomeScreen(
                onNavigate = { currentScreen = it }
            )
            Routes.ENVIRONMENT -> EnvironmentScreen(
                onNavigate = { currentScreen = it }
            )
            Routes.DASHBOARD -> DashboardScreen(
                onNavigate = { currentScreen = it }
            )
            Routes.UV_LIGHT_DASHBOARD -> UVLightDashboardScreen(
                onNavigate = { currentScreen = it }
            )
            // Add more screens as needed
            else -> HomeScreen(
                onNavigate = { currentScreen = it }
            )
        }
    }
}
